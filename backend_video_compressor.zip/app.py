
from flask import Flask, request, jsonify, send_file
import moviepy.editor as mp
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)
UPLOAD_FOLDER = "uploads"
PROCESSED_FOLDER = "compressed"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(PROCESSED_FOLDER, exist_ok=True)

@app.route("/compress", methods=["POST"])
def compress_video():
    if 'video' not in request.files:
        return jsonify({"error": "No video part"}), 400
    file = request.files['video']
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400

    filename = secure_filename(file.filename)
    input_path = os.path.join(UPLOAD_FOLDER, filename)
    output_path = os.path.join(PROCESSED_FOLDER, f"compressed_{filename}")
    file.save(input_path)

    try:
        clip = mp.VideoFileClip(input_path)
        clip.write_videofile(output_path, bitrate="500k")
    except Exception as e:
        return jsonify({"error": str(e)}), 500

    return send_file(output_path, as_attachment=True)

if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0')
